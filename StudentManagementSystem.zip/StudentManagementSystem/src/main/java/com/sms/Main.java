package com.sms;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        StudentDAO dao = new StudentDAO();

        while (true) {

            System.out.println("\n===== STUDENT MENU =====");
            System.out.println("1. Add Student");
            System.out.println("2. View Students");
            System.out.println("3. Delete Student");
            System.out.println("4. Search Student");
            System.out.println("5. Update Student");
            System.out.println("6. Exit");

            System.out.print("Enter choice: ");
            int choice = sc.nextInt();

            switch (choice) {

                case 1:
                    System.out.print("Name: ");
                    String name1 = sc.next();

                    System.out.print("Age: ");
                    int age1 = sc.nextInt();

                    System.out.print("Marks: ");
                    int marks1 = sc.nextInt();

                    System.out.print("City: ");
                    String city1 = sc.next();

                    dao.addStudent(new Student(name1, age1, marks1, city1));
                    break;

                case 2:
                    dao.viewStudents();
                    break;

                case 3:
                    System.out.print("Enter ID: ");
                    int delId = sc.nextInt();
                    dao.deleteStudent(delId);
                    break;

                case 4:
                    System.out.print("Enter ID: ");
                    int searchId = sc.nextInt();
                    dao.searchStudent(searchId);
                    break;

                case 5:
                    System.out.print("Enter ID: ");
                    int updateId = sc.nextInt();

                    System.out.print("Name: ");
                    String name2 = sc.next();

                    System.out.print("Age: ");
                    int age2 = sc.nextInt();

                    System.out.print("Marks: ");
                    int marks2 = sc.nextInt();

                    System.out.print("City: ");
                    String city2 = sc.next();

                    dao.updateStudent(new Student(updateId, name2, age2, marks2, city2));
                    break;

                case 6:
                    System.out.println("Exiting...");
                    sc.close();
                    System.exit(0);
            }
        }
    }
}