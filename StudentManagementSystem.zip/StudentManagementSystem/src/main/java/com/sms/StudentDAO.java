package com.sms;

import java.sql.*;
import com.sms.DBConnection;

public class StudentDAO {

    // ADD STUDENT
    public void addStudent(Student s) {

        try {
            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO student(name, age, marks, city) VALUES(?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, s.getName());
            ps.setInt(2, s.getAge());
            ps.setInt(3, s.getMarks());
            ps.setString(4, s.getCity());

            ps.executeUpdate();

            System.out.println("Student Added Successfully!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // VIEW STUDENTS
    public void viewStudents() {

        try {
            Connection con = DBConnection.getConnection();

            String sql = "SELECT * FROM student";

            PreparedStatement ps = con.prepareStatement(sql);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                System.out.println(
                    rs.getInt("id") + " | " +
                    rs.getString("name") + " | " +
                    rs.getInt("age") + " | " +
                    rs.getInt("marks") + " | " +
                    rs.getString("city")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // DELETE STUDENT
    public void deleteStudent(int id) {

        try {
            Connection con = DBConnection.getConnection();

            String sql = "DELETE FROM student WHERE id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);

            ps.executeUpdate();

            System.out.println("Student Deleted!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // SEARCH STUDENT
    public void searchStudent(int id) {

        try {
            Connection con = DBConnection.getConnection();

            String sql = "SELECT * FROM student WHERE id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                System.out.println(rs.getInt("id") + " | " +
                                   rs.getString("name") + " | " +
                                   rs.getInt("age") + " | " +
                                   rs.getInt("marks") + " | " +
                                   rs.getString("city"));
            } else {
                System.out.println("Student Not Found!");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
 // UPDATE STUDENT
    public void updateStudent(Student s) {

        try {
            Connection con = DBConnection.getConnection();

            String sql = "UPDATE student SET name=?, age=?, marks=?, city=? WHERE id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, s.getName());
            ps.setInt(2, s.getAge());
            ps.setInt(3, s.getMarks());
            ps.setString(4, s.getCity());
            ps.setInt(5, s.getId());

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Student Updated Successfully!");
            } else {
                System.out.println("Student ID not found!");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}