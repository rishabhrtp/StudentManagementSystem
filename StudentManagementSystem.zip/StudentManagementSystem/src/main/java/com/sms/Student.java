package com.sms;

public class Student {
	private int id;
	private String name;
	private int age;
	private int marks;
	private String city;
	
	public Student() {}
	
	public Student(int id, String name, int age, int marks, String city) {
		this.id = id;
		this.name = name;
		this.age = age;
		this.marks = marks;
		this.city = city;
	}
	public Student(String name, int age, int marks, String city) {
		this.name = name;
		this.age = age;
		this.marks = marks;
		this.city = city;
	}
    public int getId() { return id; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public int getMarks() { return marks; }
    public String getCity() { return city; }

    public void setId(int id) { this.id = id; 
    }

}
